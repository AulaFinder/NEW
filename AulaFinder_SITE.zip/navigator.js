/* AulaFinder · Navigatore scolastico V24.
 * PERCORSI SCHEMATICI: i segmenti di corridoio sono una ricostruzione dai disegni SVG,
 * non una verifica topografica della posizione delle porte o delle barriere architettoniche.
 * È vietato usarli per evacuazione o emergenze.
 */
(() => {
  'use strict';
  const root=document.getElementById('navigatorPage');
  if(!root) return;
  const $=sel=>root.querySelector(sel);
  const NS='http://www.w3.org/2000/svg';
  const floors=['sotto','terra','primo','secondo','terzo'];
  const labels={sotto:'Piano sotterraneo',terra:'Piano terra',primo:'Piano 1',secondo:'Piano 2',terzo:'Piano 3'};
  const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().trim().replace(/\s+/g,' ');
  const canon=s=>norm(s).replace(/^AULA\s+/,'').replace(/[.\s]/g,'');
  const safe=s=>String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const svgNode=(tag,attributes={})=>{const el=document.createElementNS(NS,tag);Object.entries(attributes).forEach(([k,v])=>el.setAttribute(k,String(v)));return el;};
  const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  const point=(x,y)=>({x,y});
  const close=(a,b)=>distance(a,b)<0.01;
  const fmt=n=>Math.round(n*100)/100;

  // Centrelines ricostruite DAI disegni del sito: nessuna distanza reale viene stimata.
  // I cinque blocchi "Scale e ascensore" rappresentano il nucleo verticale principale.
  const halls={
    sotto:[[[692,126],[745,126],[781,126]],[[746,76],[746,126]],[[781,114],[781,126],[781,225]],[[781,114],[905,114]],[[781,225],[745,225]],[[781,225],[781,259],[818,259],[818,271]]],
    terra:[[[260,393],[382,393]],[[382,393],[382,416]],[[382,393],[392,393],[392,367],[440,367],[523,367]],[[392,367],[392,352],[441,352]],[[441,352],[441,367]],[[440,367],[440,383]],[[427,383],[523,383]],[[407,367],[407,460],[407,477]],[[523,383],[529,383]]],
    primo:[[[260,119],[377,119],[430,119],[535,119]],[[377,119],[377,141]],[[430,119],[430,92],[430,77],[409,77]],[[483,119],[483,94]],[[535,119],[535,111]]],
    secondo:[[[618,462],[738,462],[790,462],[790,450],[897,450]],[[738,462],[738,485]],[[738,462],[738,416],[790,416]],[[790,416],[790,450]],[[806,450],[806,435]],[[846,450],[846,436]],[[897,450],[897,442]]],
    terzo:[[[630,559],[740,559],[750,559],[795,559],[795,553],[896,553]],[[750,559],[750,583]],[[816,557.752475],[816,535]],[[855,555.435644],[855,535]],[[896,553],[905,552]]]
  };
  // Le piantine sorgenti sono nascoste mentre è aperto il Navigatore.
  // Chromium/Safari restituiscono getBBox() = 0 e isPointInFill() = false
  // per gli SVG sotto [hidden]. Calcoliamo la geometria su copie renderizzate
  // fuori schermo, invisibili all'utente ma NON display:none.
  const geometrySurfaces=new Map(),geometryCorridors=new Map();
  function geometrySurface(floor){
    if(geometrySurfaces.has(floor))return geometrySurfaces.get(floor);
    const original=document.querySelector('#'+floor+' svg.plan');
    if(!original)return null;
    const svg=svgNode('svg',{viewBox:original.getAttribute('viewBox'),'aria-hidden':'true',focusable:'false'});
    svg.style.cssText='position:fixed;left:-20000px;top:0;width:600px;height:600px;opacity:0;pointer-events:none;z-index:-999';
    const corridor=original.querySelector(':scope > g.plan-rotated > path, :scope > path')?.cloneNode(true);
    if(corridor){svg.appendChild(corridor);geometryCorridors.set(floor,corridor);}
    document.body.appendChild(svg);
    geometrySurfaces.set(floor,svg);
    return svg;
  }
  function boundsOf(el,floor){
    const surface=geometrySurface(floor);
    if(!surface)return null;
    const shape=el.cloneNode(true);surface.appendChild(shape);
    const b=shape.getBBox();shape.remove();
    return b;
  }
  // Dati delle aule leggibili dalle mappe già presenti nella V23.
  const locations=[];
  floors.forEach(floor=>{
    const map=document.querySelector('#'+floor+' svg.plan');
    if(!map)return;
    map.querySelectorAll('g.room').forEach(g=>{
      const text=(g.dataset.t||'').split('·')[0].trim();
      if(!/^(?:[STP]\.\d+|[123]\.\d+|Palestra|Ingresso|Archivio|Caldaie)$/i.test(text))return;
      const box=g.querySelector('rect.box,rect.entrance-box,path.box,rect,path');
      if(!box)return;
      // The English laboratory (2.14) has an irregular SVG path, not a rect.
      // getBBox handles both shapes so it remains navigable like every other classroom.
      const bounds=boundsOf(box,floor);
      if(!bounds||!bounds.width||!bounds.height)return;
      const x=bounds.x,y=bounds.y,w=bounds.width,h=bounds.height;
      // La Palestra è raggiungibile da entrambe le mappe. Il punto di
      // instradamento è l'accesso sul corridoio, NON il centro del locale:
      // il rettangolo della palestra resta fuori dal grafo transitabile.
      const gymEntry=text==='Palestra' ? (floor==='sotto'?{x:781,y:255}:
        floor==='terra'?{x:407,y:475}:null) : null;
      locations.push({id:text,floor,description:(g.dataset.t||'').split('·').slice(1).join('·').trim(),cx:gymEntry?.x??Number(g.dataset.cx),cy:gymEntry?.y??Number(g.dataset.cy),rect:{x,y,w,h}});
    });
  });
  const uniq=new Map();
  // La Palestra ha due ingressi, seminterrato e terra. Le due geometrie
  // sono mantenute in locations e confrontate dal navigatore; solo il testo
  // del suggerimento utilizza un identificativo singolo.
  locations.forEach(r=>{const key=canon(r.id);if(!uniq.has(key)||r.id==='Palestra'&&r.floor==='terra')uniq.set(key,r);});
  const selectable=[...uniq.values()].sort((a,b)=>floors.indexOf(a.floor)-floors.indexOf(b.floor)||a.id.localeCompare(b.id,'it',{numeric:true}));
  // Every room visible on the plans is available in text search, including specialist labs.
  // Descriptions are alternative names; we never guess a room merely from a shared number.
  const searchNorm=s=>norm(s).replace(/[^A-Z0-9]/g,'');
  const roomAliases=loc=>{
    const desc=loc.description||'';
    const simplified=desc.replace(/^(?:LAB\.?|LABORATORIO)\s*(?:DI\s*)?/i,'');
    return [loc.id,`Aula ${loc.id}`,desc,`${desc} ${loc.id}`,`Lab ${simplified}`,`Laboratorio di ${simplified}`].filter(Boolean).map(searchNorm);
  };
  const lookup=s=>{
    const exact=uniq.get(canon(s));if(exact)return exact;
    const key=searchNorm(s);if(!key)return null;
    const matches=selectable.filter(loc=>roomAliases(loc).includes(key));
    return matches.length===1?matches[0]:null;
  };
  const variants=s=>locations.filter(r=>canon(r.id)===canon(s));
  const from=$('#navFrom'),to=$('#navTo');
  // Custom suggestion list replaces the native datalist. Native suggestions wrongly
  // match the same room number across different floors (e.g. T.01 vs 2.01).
  const fieldChoices=new Map([[from,$('#navFromSuggestions')],[to,$('#navToSuggestions')]]);
  const roomsOnFloor=prefix=>selectable.filter(loc=>{
    if(prefix==='S')return loc.floor==='sotto'&&/^S\./i.test(loc.id);
    if(prefix==='P')return loc.floor==='sotto'&&/^P\./i.test(loc.id);
    if(prefix==='T')return loc.floor==='terra'&&/^T\./i.test(loc.id);
    return loc.floor===({1:'primo',2:'secondo',3:'terzo'}[prefix]);
  });
  let selectedSuggestion=-1;
  function suggestionCandidates(raw){
    const q=searchNorm(raw);
    if(!q)return selectable.map(loc=>({loc,score:0}));
    const floorToken=norm(raw).replace(/^(?:AULA)\s*/,'').match(/^([SPT123])(?=\.|\s|\d|$)/);
    const floorPool=floorToken?roomsOnFloor(floorToken[1]):selectable;
    return floorPool.map(loc=>{
      const aliases=roomAliases(loc);
      const exact=aliases.some(a=>a===q);
      const starts=aliases.some(a=>a.startsWith(q));
      const token=aliases.some(a=>a.includes(q));
      const score=exact?130:starts?100:token?60:-1;
      return {loc,score};
    }).filter(x=>x.score>=0).sort((a,b)=>b.score-a.score||selectable.indexOf(a.loc)-selectable.indexOf(b.loc));
  }
  function hideSuggestions(input){
    const list=fieldChoices.get(input);if(!list)return;
    list.hidden=true;input.setAttribute('aria-expanded','false');selectedSuggestion=-1;
  }
  function showSuggestions(input){
    const list=fieldChoices.get(input);if(!list)return;
    for(const other of fieldChoices.keys())if(other!==input)hideSuggestions(other);
    const hits=suggestionCandidates(input.value);
    list.innerHTML=hits.length?hits.map(({loc},i)=>`<button type="button" role="option" data-nav-choice="${loc.id}" aria-selected="false" data-idx="${i}"><strong>${loc.id}</strong>${loc.description?`<span>${loc.description}</span>`:''}<small>${labels[loc.floor]}</small></button>`).join(''):'<p class="nav-no-matches">Nessun ambiente trovato.</p>';
    list.hidden=false;input.setAttribute('aria-expanded','true');selectedSuggestion=-1;
  }
  // Torna al modulo Da/A dopo una selezione anche da una piantina molto in basso.
  function scrollToNavigatorTop(){
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const y=window.scrollY+root.getBoundingClientRect().top-8;
      window.scrollTo({top:Math.max(0,y),behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
    }));
  }
  function pickSuggestion(input,id){
    const loc=lookup(id);if(!loc)return;
    input.value=loc.id;
    hideSuggestions(input);
    invalidateRoute();
    scrollToNavigatorTop();
  }
  fieldChoices.forEach((list,input)=>{
    input.addEventListener('focus',()=>showSuggestions(input));
    input.addEventListener('input',()=>showSuggestions(input));
    input.addEventListener('keydown',e=>{
      if(e.key==='Escape'){hideSuggestions(input);return;}
      const buttons=[...list.querySelectorAll('[data-nav-choice]')];
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){
        e.preventDefault();if(list.hidden)showSuggestions(input);
        const options=[...list.querySelectorAll('[data-nav-choice]')];if(!options.length)return;
        selectedSuggestion=(selectedSuggestion+(e.key==='ArrowDown'?1:-1)+options.length)%options.length;
        options.forEach((b,i)=>b.setAttribute('aria-selected',String(i===selectedSuggestion)));
        options[selectedSuggestion].scrollIntoView({block:'nearest'});
      }else if(e.key==='Enter'&&!list.hidden&&buttons.length){
        e.preventDefault();pickSuggestion(input,buttons[Math.max(selectedSuggestion,0)].dataset.navChoice);
      }
    });
    // Selezione con un SOLO tocco/clic, anche se il campo perde il focus.
    // Manteniamo lo scroll touch della lista: un trascinamento non seleziona l'aula.
    let press=null,ignoreClick=false;
    list.addEventListener('pointerdown',e=>{
      const btn=e.target.closest('[data-nav-choice]');
      press=btn?{id:btn.dataset.navChoice,x:e.clientX,y:e.clientY,type:e.pointerType}:null;
      if(btn && e.pointerType==='mouse'){
        e.preventDefault();ignoreClick=true;
        pickSuggestion(input,btn.dataset.navChoice);
      }
    });
    list.addEventListener('pointerup',e=>{
      if(!press)return;
      const candidate=press;press=null;
      if(candidate.type==='mouse')return;
      if(Math.hypot(e.clientX-candidate.x,e.clientY-candidate.y)>10)return;
      ignoreClick=true;
      pickSuggestion(input,candidate.id);
    });
    list.addEventListener('pointercancel',()=>{press=null;});
    list.addEventListener('click',e=>{
      if(ignoreClick){ignoreClick=false;return;}
      const btn=e.target.closest('[data-nav-choice]');
      if(btn)pickSuggestion(input,btn.dataset.navChoice);
    });
    input.addEventListener('blur',()=>{
      window.setTimeout(()=>{if(!press && !list.contains(document.activeElement))hideSuggestions(input);},170);
    });
  });
  document.addEventListener('pointerdown',e=>{
    fieldChoices.forEach((list,input)=>{if(!input.closest('.navigator-field').contains(e.target))hideSuggestions(input);});
  });
  let activePick='from';
  let latestRoute=null;
  let pickerFloor='terra';
  const currentFields=()=>[lookup(from.value),lookup(to.value)];
  // Scale e ascensori allineati per posizione su tutti i livelli.
  // Ogni gruppo è associato per posizione, non solo tramite etichetta generica.
  const laneHints={
    core:{sotto:[751.865,142.750],terra:[381.35,417.07],primo:[376.95,141.095],secondo:[738.915,485.605],terzo:[749.965,583.145]},
    eastStairs:{sotto:[817.525,100.985],terra:[441.060,368.970],primo:[444.780,93.685],secondo:[806.145,436.090],terzo:[816.800,535.385]},
    farStairs:{sotto:[903.625,115.890],terra:[529.480,385.120],primo:[535.655,111.080],secondo:[898.100,450.820],terzo:[905.815,552.390]},
    eastLift:{primo:[483.125,93.685],secondo:[846.295,436.090],terzo:[855.020,535.385]}
  };
  const connectors=[];
  Object.entries(laneHints).forEach(([lane,byFloor])=>Object.entries(byFloor).forEach(([floor,[x,y]])=>{
    const nodes=[...document.querySelectorAll('#'+floor+' g.room')];
    const g=nodes.filter(el=>lane==='eastLift'?/ascensore/i.test(el.dataset.t)&&!/scale/i.test(el.dataset.t):/scale/i.test(el.dataset.t)).sort((a,b)=>Math.hypot(+a.dataset.cx-x,+a.dataset.cy-y)-Math.hypot(+b.dataset.cx-x,+b.dataset.cy-y))[0];
    if(!g)return;
    const dist=Math.hypot(+g.dataset.cx-x,+g.dataset.cy-y);
    if(dist>22)return;
    const rect=g.querySelector('rect');
    connectors.push({id:lane+'-'+floor,lane,floor,cx:+g.dataset.cx,cy:+g.dataset.cy,rect:{x:+rect.getAttribute('x'),y:+rect.getAttribute('y'),w:+rect.getAttribute('width'),h:+rect.getAttribute('height')}});
  }));
  const routeCache=new Map();
  function cachedHall(floor,a,b){
    const key=`${floor}:${a.id}:${a.cx}:${a.cy}>${b.id}:${b.cx}:${b.cy}`;
    if(routeCache.has(key))return routeCache.get(key);
    const pts=shortestHall(floor,a,b);
    routeCache.set(key,pts);
    return pts;
  }
  const routeLength=points=>points?.slice(1).reduce((sum,p,i)=>sum+distance(p,points[i]),0)??Infinity;
  const notice=(message,error=false)=>{$('#navMessage').textContent=message;$('#navMessage').classList.toggle('nav-error',error)};
  const allSegments=floor=>(halls[floor]||[]).flatMap(line=>line.slice(1).map((pt,i)=>[point(...line[i]),point(...pt)]));
  function projection(p,a,b){const dx=b.x-a.x,dy=b.y-a.y;const len=dx*dx+dy*dy||1;const t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/len));return point(a.x+t*dx,a.y+t*dy);}
  // V52: build a segment graph from the hand-checked corridor centrelines.
  // Intersection points are explicit graph vertices. This avoids A* detours
  // toward walls or across dead-end corridors, while checking the SVG fill.
  function spineHall(floor,start,end){
    const corridor=geometryCorridors.get(floor);
    const lines=allSegments(floor);
    if(!corridor||!lines.length||!start||!end)return null;
    const inHall=p=>{
      try{return corridor.isPointInFill(new DOMPoint(p.x,p.y));}
      catch(_){return false;}
    };
    const validSegment=(a,b)=>{
      const n=Math.max(3,Math.ceil(distance(a,b)/3));
      for(let i=0;i<=n;i++){
        const t=i/n,p=point(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t);
        if(!inHall(p))return false;
      }
      return true;
    };
    const edges=lines.filter(([a,b])=>validSegment(a,b));
    if(!edges.length)return null;
    const attach=loc=>{
      let best=null;
      for(let i=0;i<edges.length;i++){
        const projected=projection(centerOf(loc),...edges[i]);
        const d=distance(centerOf(loc),projected);
        if(!best||d<best.dist)best={segment:i,p:projected,dist:d};
      }
      return best;
    };
    const a=attach(start),b=attach(end);
    if(!a||!b)return null;
    const vertexKey=p=>fmt(p.x)+','+fmt(p.y);
    const points=new Map(),links=new Map();
    function vertex(p){const key=vertexKey(p);if(!points.has(key)){points.set(key,p);links.set(key,[]);}return key;}
    function link(a,b){const x=vertex(a),y=vertex(b);if(x===y)return;
      const length=distance(a,b);links.get(x).push([y,length]);links.get(y).push([x,length]);}
    const onSegment=(p,start,end)=>{
      const cross=Math.abs((p.x-start.x)*(end.y-start.y)-(p.y-start.y)*(end.x-start.x));
      return cross<.03&&p.x>=Math.min(start.x,end.x)-.02&&p.x<=Math.max(start.x,end.x)+.02&&p.y>=Math.min(start.y,end.y)-.02&&p.y<=Math.max(start.y,end.y)+.02;
    };
    const intersections=[];
    for(let i=0;i<edges.length;i++)for(let j=i+1;j<edges.length;j++){
      const p=intersection(edges[i][0],edges[i][1],edges[j][0],edges[j][1]);
      if(p&&onSegment(p,...edges[i])&&onSegment(p,...edges[j])&&inHall(p))intersections.push(p);
    }
    edges.forEach(([u,v],i)=>{
      const pieces=[u,v,...intersections.filter(pt=>onSegment(pt,u,v))];
      if(i===a.segment)pieces.push(a.p);
      if(i===b.segment)pieces.push(b.p);
      pieces.sort((x,y)=>distance(x,u)-distance(y,u));
      for(let j=1;j<pieces.length;j++)link(pieces[j-1],pieces[j]);
    });
    const source=vertex(a.p),target=vertex(b.p);
    if(source===target)return [points.get(source)];
    const cost=new Map([...points.keys()].map(k=>[k,Infinity]));cost.set(source,0);
    const previous=new Map(),pending=new Set(points.keys());
    while(pending.size){
      let current=null,min=Infinity;
      for(const key of pending){if(cost.get(key)<min){current=key;min=cost.get(key);}}
      if(!current||!Number.isFinite(min))break;
      if(current===target)break;
      pending.delete(current);
      for(const [next,w] of links.get(current)||[]){
        const total=min+w;
        if(total<cost.get(next)){cost.set(next,total);previous.set(next,current);}
      }
    }
    if(!Number.isFinite(cost.get(target)))return null;
    const result=[];for(let k=target;k;k=previous.get(k)){
      result.push(points.get(k));if(k===source)break;
    }
    result.reverse();
    // Drop intermediate collinear vertices: smooth, geometrically verified path.
    return result.filter((p,i)=>{
      if(i===0||i===result.length-1)return true;
      const before=result[i-1],after=result[i+1];
      return Math.abs((p.x-before.x)*(after.y-p.y)-(p.y-before.y)*(after.x-p.x))>.05;
    });
  }
  function entranceFor(loc,segments){
    const {x,y,w,h}=loc.rect;
    const sides=[point(x+w/2,y),point(x+w/2,y+h),point(x,y+h/2),point(x+w,y+h/2)];
    let chosen=null;
    sides.forEach(door=>segments.forEach(([a,b],idx)=>{
      const snap=projection(door,a,b),dist=distance(door,snap);
      if(!chosen||dist<chosen.dist)chosen={door,snap,idx,dist};
    }));
    return chosen;
  }
  const cross=(a,b)=>a.x*b.y-a.y*b.x;
  function intersection(a,b,c,d){
    const r=point(b.x-a.x,b.y-a.y),s=point(d.x-c.x,d.y-c.y);
    const denom=cross(r,s);if(Math.abs(denom)<1e-9)return null;
    const q=point(c.x-a.x,c.y-a.y),t=cross(q,s)/denom,u=cross(q,r)/denom;
    if(t<-.00001||t>1.00001||u<-.00001||u>1.00001)return null;
    return point(a.x+t*r.x,a.y+t*r.y);
  }
  // Il Navigatore costruisce un grafo dalle aree di corridoio REALMENTE disegnate,
  // anziché attraversare in diagonale le pareti. Non implica percorsi verificati sul posto.
  const walkGridCache=new Map();
  function walkingGrid(floor){
    if(walkGridCache.has(floor))return walkGridCache.get(floor);
    const svg=document.querySelector('#'+floor+' svg.plan');
    const corridor=geometryCorridors.get(floor);
    if(!svg||!corridor||typeof corridor.isPointInFill!=='function')return null;
    const vb=svg.viewBox.baseVal,step=1.6;
    const nx=Math.ceil(vb.width/step)+1,ny=Math.ceil(vb.height/step)+1;
    const rooms=locations.filter(loc=>loc.floor===floor).map(loc=>{const r=loc.rect;return{
      x:r.x+.20,y:r.y+.20,x2:r.x+r.w-.20,y2:r.y+r.h-.20
    };});
    const valid=new Uint8Array(nx*ny),coord=n=>point(vb.x+(n%nx)*step,vb.y+Math.floor(n/nx)*step);
    for(let i=0;i<valid.length;i++){
      const p=coord(i);
      if(rooms.some(r=>p.x>=r.x&&p.x<=r.x2&&p.y>=r.y&&p.y<=r.y2))continue;
      if(corridor.isPointInFill(new DOMPoint(p.x,p.y)))valid[i]=1;
    }
    // Distanza approssimata dai muri (celle). Favorisce il centro del corridoio.
    const clearance=new Uint16Array(valid.length);
    clearance.fill(60000);
    for(let i=0;i<valid.length;i++)if(!valid[i])clearance[i]=0;
    // Due passaggi Manhattan; il bordo della viewBox conta come ostacolo.
    for(let y=0;y<ny;y++)for(let x=0;x<nx;x++){
      const i=y*nx+x;
      clearance[i]=Math.min(clearance[i],x===0||y===0?0:60000,
        x>0?clearance[i-1]+1:60000,y>0?clearance[i-nx]+1:60000);
    }
    for(let y=ny-1;y>=0;y--)for(let x=nx-1;x>=0;x--){
      const i=y*nx+x;
      clearance[i]=Math.min(clearance[i],x===nx-1||y===ny-1?0:60000,
        x<nx-1?clearance[i+1]+1:60000,y<ny-1?clearance[i+nx]+1:60000);
    }
    const grid={nx,ny,valid,coord,clearance};walkGridCache.set(floor,grid);return grid;
  }
  function actualHall(floor,start,end){
    const grid=walkingGrid(floor);if(!grid)return undefined;
    const {nx,valid,coord,clearance}=grid;
    const validCells=[];
    for(let i=0;i<valid.length;i++)if(valid[i])validCells.push(i);
    function nearest(loc){let best=-1,dist=Infinity;
      for(const i of validCells){const p=coord(i),d=(p.x-loc.cx)**2+(p.y-loc.cy)**2;
        if(d<dist){dist=d;best=i;}}
      return best;
    }
    const source=nearest(start),target=nearest(end);
    if(source<0||target<0)return null;
    if(source===target)return [coord(source)];
    // Four direction states per cell make the number of bends part of the
    // optimization. Every segment remains horizontal or vertical and inside
    // the hallway polygons, with no diagonal shortcuts through classrooms.
    const n=valid.length*4;
    const prev=new Int32Array(n);prev.fill(-1);
    const costs=new Float64Array(n);costs.fill(Infinity);
    const visited=new Uint8Array(n),heap=[];
    const tx=target%nx,ty=(target-tx)/nx;
    const directions=[-1,1,-nx,nx];
    const push=(s,g)=>{
      const cell=s>>2,x=cell%nx,y=(cell-x)/nx;
      const f=g+Math.abs(x-tx)+Math.abs(y-ty);
      const item=[s,g,f];let k=heap.length;heap.push(item);
      while(k>0){const p=(k-1)>>1;if(heap[p][2]<=item[2])break;heap[k]=heap[p];k=p;}heap[k]=item;
    };
    const pop=()=>{
      const top=heap[0],last=heap.pop();
      if(heap.length){let k=0;while(true){let c=k*2+1;if(c>=heap.length)break;
        if(c+1<heap.length&&heap[c+1][2]<heap[c][2])c++;
        if(heap[c][2]>=last[2])break;heap[k]=heap[c];k=c;
      }heap[k]=last;}return top;
    };
    for(let d=0;d<4;d++){const state=(source<<2)|d;costs[state]=0;push(state,0);}
    let final=-1;
    while(heap.length){
      const [u,g]=pop();if(visited[u]||g>costs[u]+1e-7)continue;
      visited[u]=1;
      const cell=u>>2,oldDir=u&3;
      if(cell===target){final=u;break;}
      const x=cell%nx;
      for(let d=0;d<4;d++){
        if(d===0&&x===0 || d===1&&x===nx-1)continue;
        const next=cell+directions[d];
        if(next<0||next>=valid.length||!valid[next])continue;
        // A decisive penalty for bends avoids the staircase/zigzag effect.
        // Near doors, a short segment close to a wall is still allowed.
        const turn=oldDir===d?0:10;
        const clearancePenalty=16.0/(clearance[next]+.9);
        const v=(next<<2)|d;
        const candidate=g+1+turn+clearancePenalty;
        if(candidate+1e-8<costs[v]){costs[v]=candidate;prev[v]=u;push(v,candidate);}
      }
    }
    if(final<0)return null;
    const cells=[];for(let u=final;u>=0;u=prev[u]){
      cells.push(u>>2);if((u>>2)===source)break;
    }
    cells.reverse();
    const points=cells.map(coord),compressed=[];
    for(let i=0;i<points.length;i++){
      if(i>0&&i<points.length-1){const a=points[i-1],b=points[i],c=points[i+1];
        if(Math.abs((b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x))<.001)continue;
      }
      compressed.push(points[i]);
    }
    return compressed.filter((p,i)=>i===0||!close(p,compressed[i-1]));
  }
  function shortestHall(floor,start,end){
    // Prefer the verified corridor centerline, with the old walkable grid as safe fallback.
    const spine=spineHall(floor,start,end);
    if(spine?.length)return spine;
    const actual=actualHall(floor,start,end);
    // Non presentare un tracciato schematico che taglia muri o esce dalla piantina.
    // Se i corridoi disegnati non collegano i due punti, nessun percorso viene mostrato.
    if(actual && actual.length)return actual;
    return null;

  }

  // Un'unica funzione SVG per i marcatori sulla mappa e quelli della legenda:
  // nessuna discrepanza tra esempio e percorso effettivo.
  function markerCircles(holder,cx,cy,kind){
    if(kind==='departure'){
      holder.append(svgNode('circle',{cx,cy,r:6.4,class:'nav-symbol-departure-ring'}));
      holder.append(svgNode('circle',{cx,cy,r:2.25,class:'nav-symbol-departure-core'}));
    }else if(kind==='stairs'){
      holder.append(svgNode('circle',{cx,cy,r:4.8,class:'nav-symbol-stairs'}));
    }
  }
  function legendCircle(kind){
    const svg=svgNode('svg',{class:'nav-legend-symbol',viewBox:'-9 -9 18 18','aria-hidden':'true'});
    markerCircles(svg,0,0,kind);
    return svg;
  }
  const arrivalPath='M12 2a8 8 0 0 0-8 8c0 5.3 8 12 8 12s8-6.7 8-12a8 8 0 0 0-8-8Zm0 11.1a3.1 3.1 0 1 1 0-6.2 3.1 3.1 0 0 1 0 6.2Z';
  function legendDestination(){
    const span=document.createElement('span');span.className='nav-legend-destination';
    const svg=svgNode('svg',{viewBox:'0 0 24 24','aria-hidden':'true'});
    const group=svgNode('g',{class:'nav-point-destination'});
    group.append(svgNode('path',{d:arrivalPath,'fill-rule':'evenodd'}));
    svg.append(group);span.append(svg);return span;
  }
  function insertLegendSymbols(){
    const host=$('#navRouteResult .nav-route-legend');if(!host)return;
    [['departure',legendCircle('departure')],['stairs',legendCircle('stairs')],['destination',legendDestination()]].forEach(([key,el])=>{
      const target=host.querySelector('[data-nav-legend="'+key+'"]');
      if(target)target.replaceChildren(el);
    });
  }
  // La linea entra e termina in centro alle aule. Ogni tratto fuori dal
  // corridoio è limitato al collegamento aula→corridoio, mai una scorciatoia tra stanze.
  const centerOf=loc=>loc?.rect?point(loc.rect.x+loc.rect.w/2,loc.rect.y+loc.rect.h/2):point(loc.cx,loc.cy);
  function routeRoomBridge(loc,hall,floor){
    if(!loc||!hall)return [];
    const r=loc.rect,center=centerOf(loc);
    if(!r)return [center];
    const inset=Math.min(1.2,r.w*.06,r.h*.06);
    const candidates=[point(center.x,r.y),point(center.x,r.y+r.h),point(r.x,center.y),point(r.x+r.w,center.y)];
    const corridor=geometryCorridors.get(floor);
    const rooms=locations.filter(q=>q.floor===floor&&q!==loc&&canon(q.id)!==canon(loc.id));
    const segmentPenalty=(a,b)=>{
      let score=0;
      for(let i=1;i<=14;i++){
        const t=i/15,x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t;
        if(rooms.some(room=>x>room.rect.x+inset&&x<room.rect.x+room.rect.w-inset&&y>room.rect.y+inset&&y<room.rect.y+room.rect.h-inset))score+=100;
        if(!corridor?.isPointInFill?.(new DOMPoint(x,y)))score+=1;
      }
      return score;
    };
    let best=null;
    for(const door of candidates){
      const bends=[point(door.x,hall.y),point(hall.x,door.y)];
      for(const bend of bends){
        const d=distance(door,bend)+distance(bend,hall);
        const penalty=segmentPenalty(door,bend)+segmentPenalty(bend,hall);
        const cost=d+penalty*8;
        if(!best||cost<best.cost)best={door,bend,cost};
      }
    }
    if(!best)return [center];
    const sequence=[center,best.door,best.bend,hall];
    return sequence.filter((v,i)=>i===0||!close(v,sequence[i-1]));
  }
  function cloneMap(floor,where,{routePoints=[],start=null,end=null,transfer=false,entryPoint=null,exitPoint=null}={}){
    where.innerHTML='';
    const original=document.querySelector('#'+floor+' svg.plan');
    if(!original)return;
    const map=original.cloneNode(true);map.classList.add('nav-plan');map.setAttribute('aria-label','Piantina schematica di '+labels[floor]);
    map.querySelectorAll('g.room').forEach(g=>{
      const text=(g.dataset.t||'').split('·')[0].trim();
      const location=locations.find(loc=>loc.floor===floor&&canon(loc.id)===canon(text));
      const valid=!!location;
      if(valid){g.classList.add('nav-room');g.setAttribute('data-nav-id',location.id);g.setAttribute('aria-label','Seleziona '+location.id);g.setAttribute('tabindex','0');}
      else{g.removeAttribute('tabindex');g.removeAttribute('role');g.classList.remove('nav-room');g.style.pointerEvents='none';}
      if((start&&canon(text)===canon(start.id))||(end&&canon(text)===canon(end.id)))g.classList.add('nav-endpoint-room');
    });
    map.querySelectorAll('.top').forEach(g=>g.remove());
    if(routePoints.length){
      const layer=svgNode('g',{class:'nav-route-layer','aria-hidden':'true'});
      // Draw the route BEHIND the room text and icons (the original g.room are appended afterwards).
      const hallway=routePoints.filter((p,i)=>i===0||!close(p,routePoints[i-1]));
      // Aulas are centered; hallway route remains the same validated path.
      const beginning=start&&hallway.length?routeRoomBridge(start,hallway[0],floor):[];
      const ending=end&&hallway.length?routeRoomBridge(end,hallway.at(-1),floor):[];
      const painted=[...beginning,...hallway,...ending.reverse()];
      const unique=painted.filter((p,i)=>i===0||!close(p,painted[i-1]));
      const d=unique.length?`M ${fmt(unique[0].x)} ${fmt(unique[0].y)} `+unique.slice(1).map(p=>`L ${fmt(p.x)} ${fmt(p.y)}`).join(' '):'';
      // Coordinate reali per il gradiente: objectBoundingBox ha altezza zero
      // nei tratti perfettamente orizzontali e alcuni browser disegnano solo il contorno.
      const gradientFrom=unique[0]||{x:0,y:0};
      const gradientTo=unique.at(-1)||{x:1,y:1};
      const noSpan=distance(gradientFrom,gradientTo)<0.01;
      const defs=svgNode('defs');
      const grad=svgNode('linearGradient',{
        id:'aula-nav-route-gradient',gradientUnits:'userSpaceOnUse',
        x1:fmt(gradientFrom.x),y1:fmt(gradientFrom.y),
        x2:fmt(gradientTo.x+(noSpan?1:0)),y2:fmt(gradientTo.y+(noSpan?1:0))
      });
      [['0%','#65F0F5'],['33%','#A68BFF'],['67%','#FAD46B'],['100%','#65F0F5']].forEach(([offset,color],i)=>{
        const stop=svgNode('stop',{offset,'stop-color':color});
        if(!window.matchMedia('(prefers-reduced-motion:reduce)').matches){
          const anim=svgNode('animate',{attributeName:'stop-color',values:i===2?'#FAD46B;#F994C9;#65F0F5;#FAD46B':'#65F0F5;#A68BFF;#FAD46B;#65F0F5',dur:'5s',repeatCount:'indefinite',begin:(i*-.9)+'s'});
          stop.append(anim);
        }
        grad.append(stop);
      });
      defs.append(grad);layer.append(defs);
      if(unique.length>1){
        layer.append(svgNode('path',{d,class:'nav-route-shadow'}));
        layer.append(svgNode('path',{d,class:'nav-route-polyline'}));
      }
      const a=hallway[0],b=hallway.at(-1);
      const firstRoom=map.querySelector('g.room');
      if(firstRoom)firstRoom.parentNode.insertBefore(layer,firstRoom);else (map.querySelector('.plan-rotated')||map).appendChild(layer);

      // V46: la legenda corrisponde esattamente ai simboli presenti sulla mappa.
      // Partenza: doppio cerchio; scale ENTRATA e USCITA: unico cerchio verde acqua;
      // arrivo: SOLO il pin delle aule, senza cerchio né sfondo.
      const markers=[];
      if(start)markers.push({p:centerOf(start),kind:'departure'});
      if(entryPoint)markers.push({p:entryPoint,kind:'stairs'});
      if(transfer&&(exitPoint||b))markers.push({p:exitPoint||b,kind:'stairs'});
      if(end)markers.push({p:centerOf(end),kind:'destination'});
      if(markers.length){
        const overlay=svgNode('g',{class:'nav-transfer-marker-layer nav-point-marker-layer','aria-hidden':'true'});
        const dedup=[];
        for(const marker of markers){
          if(dedup.some(prev=>prev.kind===marker.kind&&close(prev.p,marker.p)))continue;
          dedup.push(marker);
        }
        dedup.forEach(({p,kind})=>{
          if(kind==='destination'){
            // La mappa è già ruotata di 180°; contro-ruotiamo solo l'icona dell'arrivo.
            const pin=svgNode('g',{class:'nav-point-destination',transform:`translate(${fmt(p.x)} ${fmt(p.y)}) rotate(180) scale(.75) translate(-12 -22)`});
            pin.append(svgNode('path',{d:arrivalPath,'fill-rule':'evenodd'}));
            overlay.append(pin);
          }else{
            markerCircles(overlay,p.x,p.y,kind);
          }
        });
        (map.querySelector('.plan-rotated')||map).appendChild(overlay);
      }
    }
    where.appendChild(map);
  }
  function renderPicker(){
    $('#navPickerFloor').value=pickerFloor;
    $('#navPickerTitle').textContent=activePick==='from'?'Scegli la partenza dalla piantina':'Scegli la destinazione dalla piantina';
    const holder=$('#navPickerMap');cloneMap(pickerFloor,holder);
  }
  function togglePicker(field){
    const picker=$('#navPicker');
    if(!picker.hidden&&activePick===field){picker.hidden=true;return}
    activePick=field;
    const loc=lookup(field==='from'?from.value:to.value);
    pickerFloor=loc?.floor||pickerFloor;
    picker.hidden=false;
    renderPicker();
    root.querySelectorAll('[data-nav-pick]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.navPick===field)));
    picker.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth',block:'nearest'});
  }
  const floorName=i=>labels[floors[i]];
  const stageState={index:0,stages:[]};
  function bestRoute(a,b,mode){
    // Include both gym levels: underground is a valid arrival without climbing to ground.
    const starts=variants(a.id).length?variants(a.id):[a];
    const ends=variants(b.id).length?variants(b.id):[b];
    // Percorso sullo stesso piano: nessun bisogno di interrogare tutte le
    // scale. Scegli anche l'ingresso sotterraneo della Palestra quando utile.
    for(const origin of starts)for(const destination of ends){
      if(origin.floor!==destination.floor)continue;
      const direct=cachedHall(origin.floor,origin,destination);
      if(direct&&direct.length) return {a:origin,b:destination,mode,
        stages:[{floor:origin.floor,points:direct,start:origin,end:destination,transfer:false}],
        cost:routeLength(direct),sameFloorGym:origin.id==='Palestra'||destination.id==='Palestra'};
    }
    let best=null;
    for(const origin of starts)for(const destination of ends){
      const fi=floors.indexOf(origin.floor),ti=floors.indexOf(destination.floor);
      const min=Math.min(fi,ti),max=Math.max(fi,ti);
      const active=connectors.filter(c=>{
        if(floors.indexOf(c.floor)<min||floors.indexOf(c.floor)>max)return false;
        return mode==='lift' ? ['core','eastLift'].includes(c.lane):c.lane!=='eastLift';
      });
      const nodes=[{...origin,id:'origin',realId:origin.id},...active,{...destination,id:'destination',realId:destination.id}];
      const pathCache=new Map();
      const edges=new Map(nodes.map((_,i)=>[i,[]]));
      const edgeDetails=new Map();
      for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){
        const u=nodes[i],v=nodes[j];
        if(u.floor===v.floor){
          // The direct trip is measured using the actual hallway sketch, never Euclidean through rooms.
          const pts=cachedHall(u.floor,u,v);
          if(!pts||!pts.length)continue;
          const w=Math.max(0.1,routeLength(pts));
          edges.get(i).push([j,w]);edges.get(j).push([i,w]);edgeDetails.set(i+','+j,pts);
        }else if(u.lane&&v.lane&&u.lane===v.lane&&Math.abs(floors.indexOf(u.floor)-floors.indexOf(v.floor))===1){
          const w=50;edges.get(i).push([j,w]);edges.get(j).push([i,w]);
        }
      }
      // Dijkstra with no detour to higher/lower floors outside the start→destination span.
      const costs=nodes.map(()=>Infinity),prev=nodes.map(()=>-1),todo=new Set(nodes.map((_,i)=>i));costs[0]=0;
      while(todo.size){let i=-1,bestCost=Infinity;for(const j of todo)if(costs[j]<bestCost){bestCost=costs[j];i=j;}
        if(i<0||i===nodes.length-1)break;todo.delete(i);
        for(const [j,w] of edges.get(i)){if(todo.has(j)&&costs[i]+w<costs[j]){costs[j]=costs[i]+w;prev[j]=i;}}
      }
      if(!Number.isFinite(costs.at(-1)))continue;
      const seq=[];let at=nodes.length-1;while(at>=0){seq.push(at);if(at===0)break;at=prev[at];}seq.reverse();
      if(seq[0]!==0)continue;
      const stages=[];let current=null;
      // Dopo ogni collegamento verticale ricordiamo il puntino sul piano
      // di arrivo, anche quando si SCENDONO le scale.
      let pendingEntry=null;
      let pendingEntryFloor=null;
      for(let k=0;k<seq.length-1;k++){
        const x=seq[k],y=seq[k+1],u=nodes[x],v=nodes[y];
        if(u.floor===v.floor){
          let pts=edgeDetails.get(Math.min(x,y)+','+Math.max(x,y));
          if(!pts)continue;
          if(x>y)pts=[...pts].reverse();
          if(!current||current.floor!==u.floor){
            current={floor:u.floor,points:[],start:null,end:null,transfer:false,entryPoint:pendingEntry,entryFromFloor:pendingEntryFloor};
            stages.push(current);pendingEntry=null;pendingEntryFloor=null;
          }
          for(const pt of pts){if(!current.points.length||!close(current.points.at(-1),pt))current.points.push(pt);}
        }else{
          if(!current||current.floor!==u.floor){
            current={floor:u.floor,points:[point(u.cx,u.cy)],start:null,end:null,transfer:false,entryPoint:pendingEntry,entryFromFloor:pendingEntryFloor};
            stages.push(current);pendingEntry=null;pendingEntryFloor=null;
          }
          current.transfer=true;
          current.exitLane=u.lane;
          current.exitPoint=point(u.cx,u.cy);
          current.exitToFloor=v.floor;
          pendingEntry=point(v.cx,v.cy);
          pendingEntryFloor=u.floor;
          current=null;
        }
      }
      if(!stages.length)stages.push({floor:origin.floor,points:[point(origin.cx,origin.cy)],start:origin,end:destination,transfer:false});
      stages[0].start=origin;
      stages[stages.length-1].end=destination;
      // Se esiste un ingresso della Palestra sullo stesso piano di partenza,
      // preferiamo quello: non aggiungere scale a un percorso tutto in piano.
      const sameFloorGym=(a.id==='Palestra'||b.id==='Palestra')&&origin.floor===destination.floor;
      const choice={a:origin,b:destination,mode,stages,cost:costs.at(-1),sameFloorGym};
      if(!best || (sameFloorGym&&!best.sameFloorGym) ||
        (sameFloorGym===best.sameFloorGym && choice.cost<best.cost))best=choice;
    }
    return best;
  }
  function renderRouteStage(index){
    if(!latestRoute)return;
    stageState.index=Math.max(0,Math.min(index,stageState.stages.length-1));
    const i=stageState.index,r=stageState.stages[i];
    const count=stageState.stages.length;
    $('#navCurrentStep').textContent=`${i+1} / ${count}`;
    $('#navStepPrev').disabled=i===0;
    $('#navStepNext').disabled=i===count-1;
    const role=count===1?'Percorso':i===0?'Partenza':i===count-1?'Arrivo':'Cambio piano';
    $('#navStepFloor').textContent=labels[r.floor];
    const floorChange=r.exitToFloor
      ? (floors.indexOf(r.exitToFloor)<floors.indexOf(r.floor)?'Scendi':'Sali')
      : null;
    const verticalMovement=r.exitToFloor
      ? `${floorChange} ${latestRoute.mode==='lift'?'con l’ascensore':'le scale'} fino a ${labels[r.exitToFloor]}.`
      : '';
    $('#navStepInstruction').textContent=count===1?`Segui il percorso evidenziato da ${latestRoute.a.id} a ${latestRoute.b.id}.`:
      i===0?`Parti da ${latestRoute.a.id}. Segui il percorso fino al puntino ${latestRoute.mode==='lift'?'dell’ascensore':'sulle scale'}. ${verticalMovement}`:
      i===count-1?`Dal puntino del collegamento verticale raggiungi ${latestRoute.b.id}.`:
      `Attraversa ${labels[r.floor]}. ${verticalMovement || 'Segui il percorso evidenziato.'}`;
    $('#navStepRole').textContent=role;
    const map=$('#navActiveMap');
    cloneMap(r.floor,map,{routePoints:r.points,start:r.start,end:r.end,transfer:r.transfer,entryPoint:r.entryPoint,exitPoint:r.exitPoint});
  }
  function invalidateRoute(){latestRoute=null;stageState.stages=[];$('#navRouteResult').hidden=true;notice('Premi Visualizza percorso per calcolare il tragitto.');}
  function performRoute(scroll=false){
    // Dopo l'avvio del percorso la lista dei suggerimenti non deve coprire la mappa.
    hideSuggestions(from);hideSuggestions(to);
    const [a,b]=currentFields();
    if(!a||!b){latestRoute=null;$('#navRouteResult').hidden=true;notice('Controlla Da e A: scegli due ambienti presenti nell’elenco o nella piantina.',true);return false;}
    if(a.id===b.id){latestRoute=null;$('#navRouteResult').hidden=true;notice('Partenza e destinazione coincidono. Seleziona due ambienti diversi.',true);return false;}
    const mode=$('#navTravelMode').value;
    const result=bestRoute(a,b,mode);
    if(!result){latestRoute=null;$('#navRouteResult').hidden=true;notice('Nessun percorso verificabile all’interno dei corridoi disegnati con questa modalità. Prova scale/ascensore o un’altra aula.',true);return false;}
    latestRoute=result;stageState.stages=result.stages;
    notice(`Percorso trovato: ${result.a.id} → ${result.b.id} · ${result.stages.length} ${result.stages.length===1?'piano':'piani'}.`);
    const target=$('#navRouteResult');target.hidden=false;
    target.innerHTML=`<div class="navigator-summary"><p>${safe(result.a.id)} → ${safe(result.b.id)}<small>${safe(labels[result.a.floor])} → ${safe(labels[result.b.floor])}</small></p><span class="nav-mode-tag">${mode==='lift'?'Ascensore':'Scale'}</span></div>
      <section class="nav-stepper" aria-label="Navigazione passo dopo passo"><div class="nav-stepper-controls"><button type="button" id="navStepPrev" aria-label="Passaggio precedente">←</button><div><span class="nav-stepper-counter" id="navCurrentStep"></span><h2 id="navStepFloor"></h2><span id="navStepRole"></span></div><button type="button" id="navStepNext" aria-label="Passaggio successivo">→</button></div>
      <div class="nav-map-legend-layout"><div class="navigator-map" id="navActiveMap"></div>
      <aside class="nav-route-legend" aria-label="Legenda del percorso"><strong>Legenda</strong>
      <div class="nav-route-legend-item"><span data-nav-legend="departure" aria-hidden="true"></span><span>Partenza</span></div>
      <div class="nav-route-legend-item"><span data-nav-legend="stairs" aria-hidden="true"></span><span>Scale / ascensore (entrata e uscita)</span></div>
      <div class="nav-route-legend-item"><span data-nav-legend="destination" aria-hidden="true"></span><span>Arrivo all’aula</span></div>
      <div class="nav-route-legend-item"><span class="nav-legend-line" aria-hidden="true"></span><span>Percorso</span></div>
      </aside></div><p id="navStepInstruction" class="navigator-route-instruction"></p></section>`;
    insertLegendSymbols();
    renderRouteStage(0);
    if(scroll)target.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
    return true;
  }
  root.addEventListener('click',e=>{if(e.target.closest('#navStepPrev'))renderRouteStage(stageState.index-1);if(e.target.closest('#navStepNext'))renderRouteStage(stageState.index+1)});
  $('#navigatorForm').addEventListener('submit',e=>{e.preventDefault();performRoute(true)});
  root.querySelectorAll('[data-nav-pick]').forEach(b=>b.addEventListener('click',()=>togglePicker(b.dataset.navPick)));
  $('#navPickerClose').addEventListener('click',()=>{$('#navPicker').hidden=true;root.querySelectorAll('[data-nav-pick]').forEach(el=>el.setAttribute('aria-pressed','false'))});
  $('#navPickerFloor').addEventListener('change',e=>{pickerFloor=e.target.value;renderPicker()});
  $('#navSwap').addEventListener('click',()=>{const value=from.value;from.value=to.value;to.value=value;hideSuggestions(from);hideSuggestions(to);invalidateRoute()});
  $('#navTravelMode').addEventListener('change',invalidateRoute);
  [from,to].forEach(input=>{
    // L'evento change puo scattare sul blur DOPO il submit: non cancellare il percorso appena calcolato.
    input.addEventListener('change',()=>{hideSuggestions(input);});
    input.addEventListener('input',invalidateRoute);
  });
  // Prevent the existing Piantina click/keyboard handlers from selecting copied SVG elements.
  root.querySelectorAll('#navPickerMap,#navRouteResult').forEach(container=>{
    container.addEventListener('click',e=>{
      const room=e.target.closest('g.nav-room');
      if(room&&container.id==='navPickerMap'){
        const input=activePick==='from'?from:to;
        input.value=room.dataset.navId;
        hideSuggestions(input);
        $('#navPicker').hidden=true;
        root.querySelectorAll('[data-nav-pick]').forEach(el=>el.setAttribute('aria-pressed','false'));
        invalidateRoute();notice(`${room.dataset.navId} selezionata. ${lookup(from.value)&&lookup(to.value)?'Premi Visualizza percorso.':'Completa l’altro campo e premi Visualizza percorso.'}`);
        scrollToNavigatorTop();
      }
      if(e.target.closest('svg.plan'))e.stopPropagation();
    },true);
    container.addEventListener('keydown',e=>{
      if((e.key==='Enter'||e.key===' ')&&e.target.closest('g.nav-room')){
        e.preventDefault();e.stopPropagation();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));
      }
    },true);
  });
  window.AulaFinderNavigator={
    route:(origin,destination)=>{from.value=origin;to.value=destination;invalidateRoute();return true;},
    setDestination:(destination)=>{const loc=lookup(destination);if(!loc)return false;to.value=loc.id;hideSuggestions(to);
      invalidateRoute();notice(`Destinazione: ${loc.id}. ${lookup(from.value)?'Premi Visualizza percorso.':'Ora scegli da quale ambiente partire.'}`);
      return true;},
    previewRoute:(origin,destination,mode="stairs")=>{const a=lookup(origin),b=lookup(destination);return a&&b&&a.id!==b.id?bestRoute(a,b,mode):null;},
    getRooms:()=>selectable.map(x=>x.id)
  };
})();
