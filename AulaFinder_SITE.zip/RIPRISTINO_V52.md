# AulaFinder V52 — Ripristino GitHub Pages

Questa è una correzione tecnica della V52, NON una V53: le funzioni e i dati della V52 sono mantenuti.

## Correzioni
- Service Worker PWA: prima `cache.addAll()` per oltre 100 risorse, fallendo completamente anche per un solo file 404; ora precache tollerante ai singoli errori.
- File JavaScript/CSS: strategia network-first con cache offline di riserva, per evitare di usare vecchie versioni del codice insieme alla nuova Home.
- Aggiunta `diagnostica.html`, autonoma, per controllare dal sito pubblicato HTTP 404 di immagini, fogli di stile e JavaScript e per ripulire le sole cache AulaFinder.
- Conservati il codice del navigatore, Finder, orari, piantine, tutorial e le anteprime V52.

## Pubblicazione consigliata senza upload manuale di 155 file
Usa `AulaFinder_SITE.zip` + `.github/workflows/pubblica.yml` consegnati nel KIT GitHub Actions.
Nel repository, in `Settings > Pages > Build and deployment`, seleziona **GitHub Actions** (NON "Deploy from a branch").
L'Action estrae il pacchetto e pubblica tutti i file completi, senza usare il limite del caricamento manuale da browser.

## Se il sito ancora non funziona
Apri `https://<utente>.github.io/<nome-repository>/diagnostica.html` e usa **Verifica file**.
Se il sito mostra 404 ma la diagnostica è raggiungibile, controlla `Settings > Pages` e la scheda `Actions`.
Se rimangono vecchie risorse, la diagnostica ha il pulsante **Ripulisci cache offline**. Non rimuove impostazioni e modifiche Admin in localStorage.

Non abbiamo verificato lo stato remoto del repository: i controlli effettuati sono sul pacchetto locale e non equivalgono a un collaudo su GitHub Pages.
